#CS4098
#Release tag: 0.3.0

#Requirements:

  make
 
  apache 2
  
  python 3.4.1

  https://github.com/jnoll/peos (requries bison [for yacc] and flex)
  
  OpenEMR (http://www.open-emr.org/wiki/index.php/OpenEMR_Downloads)
  
#Installation:

Install OpenEMR
  
  Download from http://www.open-emr.org/wiki/index.php/OpenEMR_Downloads

Run make in peos directory

Clone git repository and run make in CS4098 directory

#OpenEMR:

 Go to OpenEMR location on server - http://localhost/openemr/

 Go to OpenEMR location on server (http://localhost/openemr)

 Sign in as admin

 Create patients
