<?php

function helloWorld()
{
	echo "Hello World \n";
}

helloWorld();
?>
