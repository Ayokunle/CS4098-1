var app = angular.module('myApp', []);
var app = angular.module('popupApp', []);